mahasiswa = {
"A001": {"nama": "Budi", "prodi": "Informatika", "ipk": 3.45},
"A002": {"nama": "Siti", "prodi": "Sistem Informasi", "ipk": 3.20},
"A003": {"nama": "Andi", "prodi": "Informatika", "ipk": 3.75} } 

print(mahasiswa["A003"]["ipk"])

ipk1 = 3.45
ipk2 = 3.20
ipk3 = 3.75

rataIPK = (ipk1 + ipk2 + ipk3) / 3
print(rataIPK)
