katalog = [
{'nama': 'Belajar Python', 'harga': 75000, 'stok': 5}, 
{'nama': 'Struktur Data', 'harga': 95000, 'stok': 3}, 
{'nama': 'Algoritma Dasar', 'harga': 60000, 'stok': 8}, ]

riwayat_buku = set()

def proses_transaksi(katalog, nama_buku: str, jumlah_beli: int):
    keyword = nama_buku.lower()

