def tambah_buku(nama, harga, stok): 
    if harga <= 0:
        harga = None
        print("Harga tidak boleh kosong")
    if stok < 0:
        stok = None
        print("Stok tidak boleh negatif")

    return {"nama" : nama, "harga" : harga, "stok": stok}

listBuku = []
for x in range(3):
    namaBuku = input("Nama buku: ")
    hargaBuku = int(input("Harga Buku: "))
    stokBuku = int(input("Stok Buku: ")) 
    listBuku.append(tambah_buku(namaBuku, hargaBuku, stokBuku))

print(listBuku, end= ",")

    
    
